
import React, { Component } from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import withNavigation from "./WithNavigation.jsx";
import ListDownloadable from "./ListDownloadable"
import Upload from './Upload'
import Uploaded from './Uploaded';
import FTSWelcome from './FTS-Welcome'
import FTSError from './Error.jsx';
import './css/fts.css';
import AuthenticateRoute from "./AuthenticateRoute.jsx";


class FTSApp extends Component {
	constructor(props) {
		super(props);
	}
	
	render() {
		const ListDownloadableWithNavigation = withNavigation(ListDownloadable);
		const UploadedWithNavigation = withNavigation(Uploaded);
		const UploadWithNavigation = withNavigation(Upload);
		const FTSWelcomeWithNavigation = withNavigation(FTSWelcome);
		const FTSErrorWithNavigation = withNavigation(FTSError);

		return (
			<>
				<Router basename="/FTS-Web/"> 				
					<Routes>
						<Route path="/welcome" element={<FTSErrorWithNavigation></FTSErrorWithNavigation>} />
						
						<Route path="/" element={
							<AuthenticateRoute>
								<FTSWelcomeWithNavigation></FTSWelcomeWithNavigation>
							</AuthenticateRoute>} />
						
						
						<Route path="/download" element={
							<AuthenticateRoute>
								<ListDownloadableWithNavigation></ListDownloadableWithNavigation>
							</AuthenticateRoute>} />

						
						<Route path="/uploaded" element={
							<AuthenticateRoute>
								<UploadedWithNavigation></UploadedWithNavigation>
							</AuthenticateRoute>} />
						
						<Route path="/upload" element={
							<AuthenticateRoute>
								<UploadWithNavigation></UploadWithNavigation>
							</AuthenticateRoute>} />
					</Routes>
				</Router>
			</>
		)
	}
	

}

export default FTSApp