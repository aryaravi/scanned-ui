import React from "react"
import FooterSlim from "./FooterSlim";
import Header from "./Header"
class FTSLayout extends React.Component {
  render(){
    //const FTSLinksWithNavigation = withNavigation(FTSLinks);
    return (
      <>
      
        <Header />
        
        <main className="main_section">{this.props.children}</main>
        <FooterSlim />
      </>
    )
  }
}
export default FTSLayout;